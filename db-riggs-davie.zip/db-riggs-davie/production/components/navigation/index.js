var e=document.querySelector('[data-component-id="navigation"]');if(e){var t=e.querySelector('[data-role="tabs-menu"]'),a=e.querySelector('[data-role="tab-button-wrapper"]');t.prepend(a)}
