var r=function(e){var t=arguments.length>1&&arguments[1]!==void 0?arguments[1]:document.head;t.insertAdjacentHTML("beforeend","<style>".concat(e,"</style>"))};export{r as i};
