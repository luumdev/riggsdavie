var c="js--",a={ACTIVE:"".concat(c,"active"),DISABLED:"".concat(c,"disabled"),OPEN:"".concat(c,"open"),CLOSED:"".concat(c,"closed"),LOCKED:"".concat(c,"locked")};export{a as C};
